import ref.alpha_hmc as alpha_hmc
import ref.bayesian_regression as bayesian_regression 
import ref.inference as  inference
import ref.nn_models as nn_models