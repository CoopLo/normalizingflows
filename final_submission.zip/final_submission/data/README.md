# Data

Toy data used for our implementations; based off data by Weiwei Pan (2019).