# Working script folder

This folder contains our Python scripts used for the various implementations and to generate some of the plots in our final notebook. Code that is more pertinent to our project narrative have been directly incorporated in our notebook and will not feature here.
