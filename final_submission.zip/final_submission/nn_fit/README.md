# BNN with Normalizing Flows Metadata

Metadata for our BNN implementation involving normalizing flows