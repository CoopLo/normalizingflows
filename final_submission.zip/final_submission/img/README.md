# Images and relevant assets

Visual assets used in final notebook
